var bfs_8cpp =
[
    [ "Build_Path", "bfs_8cpp.html#a8f376c439a8c6592c77e95d843f2d469", null ],
    [ "Improve_Matching", "bfs_8cpp.html#a54a7628506dd10a60f6b345020cb1522", null ],
    [ "Is_A_Vertex", "bfs_8cpp.html#af1e357a8074189d16a78f60f1aaba1b8", null ],
    [ "Is_B_Vertex", "bfs_8cpp.html#a8aedd1fa216a9fed262caabd36f1faa5", null ],
    [ "Is_Invalid", "bfs_8cpp.html#a5ab15092366bed60877b7b5bf840b691", null ],
    [ "Is_Matching_Edge", "bfs_8cpp.html#a619587bed532f427533ceb8912c25a11", null ],
    [ "Modified_BFS", "bfs_8cpp.html#ab87aced755545c3d1bf1e4c2b6933c8e", null ],
    [ "Print_BFS_Path", "bfs_8cpp.html#a8bf4a5c7346aa073edd9a0bbc03b340a", null ],
    [ "Vertex_Id", "bfs_8cpp.html#ae00faf5263859d02f614786a25e6828e", null ]
];
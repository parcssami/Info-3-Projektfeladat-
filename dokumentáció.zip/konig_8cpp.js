var konig_8cpp =
[
    [ "Konig_Denes", "konig_8cpp.html#a80c36e9266b2121f595eb6f234614810", null ],
    [ "Print_Konig_Cover", "konig_8cpp.html#a01add277650d04670f387945094447a0", null ]
];
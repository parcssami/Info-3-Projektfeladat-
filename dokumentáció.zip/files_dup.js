var files_dup =
[
    [ "bfs.cpp", "bfs_8cpp.html", "bfs_8cpp" ],
    [ "bfs.h", "bfs_8h.html", "bfs_8h" ],
    [ "graph.cpp", "graph_8cpp.html", null ],
    [ "graph.h", "graph_8h.html", "graph_8h" ],
    [ "konig.cpp", "konig_8cpp.html", "konig_8cpp" ],
    [ "konig.h", "konig_8h.html", "konig_8h" ],
    [ "main.cpp", "main_8cpp.html", "main_8cpp" ]
];
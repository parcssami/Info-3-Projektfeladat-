var searchData=
[
  ['bipartite_5fgraph_0',['Bipartite_Graph',['../class_bipartite___graph.html',1,'']]]
];

var searchData=
[
  ['component_5fa_0',['component_A',['../class_bipartite___graph.html#a9177e4de2407dec9185fbb7dee226f5f',1,'Bipartite_Graph']]],
  ['component_5fb_1',['component_B',['../class_bipartite___graph.html#a5b0308c0c2882b257480e92c7fc06f04',1,'Bipartite_Graph']]]
];

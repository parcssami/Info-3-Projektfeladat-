var indexSectionsWithContent =
{
  0: "abcdegikmnpv",
  1: "b",
  2: "bgkm",
  3: "abdgikmnpv",
  4: "ce"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "variables"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Files",
  3: "Functions",
  4: "Variables"
};


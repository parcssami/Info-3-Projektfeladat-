var searchData=
[
  ['vertex_5fid_0',['Vertex_Id',['../bfs_8cpp.html#ae00faf5263859d02f614786a25e6828e',1,'bfs.cpp']]]
];

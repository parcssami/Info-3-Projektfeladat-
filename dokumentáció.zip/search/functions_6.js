var searchData=
[
  ['main_0',['main',['../main_8cpp.html#ae66f6b31b5ad750f1fe042a706a4e3d4',1,'main.cpp']]],
  ['modified_5fbfs_1',['Modified_BFS',['../bfs_8cpp.html#ab87aced755545c3d1bf1e4c2b6933c8e',1,'Modified_BFS(const Bipartite_Graph &amp;G, const Bipartite_Graph &amp;M):&#160;bfs.cpp'],['../bfs_8h.html#ab87aced755545c3d1bf1e4c2b6933c8e',1,'Modified_BFS(const Bipartite_Graph &amp;G, const Bipartite_Graph &amp;M):&#160;bfs.cpp']]]
];

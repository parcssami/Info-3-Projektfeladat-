var searchData=
[
  ['neighbours_5fof_5fa_0',['Neighbours_Of_A',['../class_bipartite___graph.html#a0da9ff0008f23d033a6336651f199a76',1,'Bipartite_Graph']]],
  ['neighbours_5fof_5fb_1',['Neighbours_Of_B',['../class_bipartite___graph.html#ae9ebdaa8bfef2334ae845e0ef6c87175',1,'Bipartite_Graph']]],
  ['numedge_2',['NumEdge',['../class_bipartite___graph.html#a4696ab8273bd4572176bab92d87e819e',1,'Bipartite_Graph']]],
  ['numvertex_3',['NumVertex',['../class_bipartite___graph.html#a24683685ddca7137c8ae1fec3fbf8848',1,'Bipartite_Graph']]],
  ['numvertex_5fa_4',['NumVertex_A',['../class_bipartite___graph.html#a0a75da8f4461b8f6d3b5b064f1a04455',1,'Bipartite_Graph']]],
  ['numvertex_5fb_5',['NumVertex_B',['../class_bipartite___graph.html#a19bd8978803c589e0fcc3df6d00115b7',1,'Bipartite_Graph']]]
];

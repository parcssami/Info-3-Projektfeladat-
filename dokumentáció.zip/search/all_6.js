var searchData=
[
  ['improve_5fmatching_0',['Improve_Matching',['../bfs_8cpp.html#a54a7628506dd10a60f6b345020cb1522',1,'Improve_Matching(Bipartite_Graph &amp;M, const vector&lt; int &gt; &amp;P):&#160;bfs.cpp'],['../bfs_8h.html#a54a7628506dd10a60f6b345020cb1522',1,'Improve_Matching(Bipartite_Graph &amp;M, const vector&lt; int &gt; &amp;P):&#160;bfs.cpp']]],
  ['is_5fa_5fvertex_1',['Is_A_Vertex',['../bfs_8cpp.html#af1e357a8074189d16a78f60f1aaba1b8',1,'bfs.cpp']]],
  ['is_5fb_5fvertex_2',['Is_B_Vertex',['../bfs_8cpp.html#a8aedd1fa216a9fed262caabd36f1faa5',1,'bfs.cpp']]],
  ['is_5finvalid_3',['Is_Invalid',['../bfs_8cpp.html#a5ab15092366bed60877b7b5bf840b691',1,'bfs.cpp']]],
  ['is_5fmatching_5fedge_4',['Is_Matching_Edge',['../bfs_8cpp.html#a619587bed532f427533ceb8912c25a11',1,'Is_Matching_Edge(const Bipartite_Graph &amp;M, int a, int b):&#160;bfs.cpp'],['../bfs_8h.html#a619587bed532f427533ceb8912c25a11',1,'Is_Matching_Edge(const Bipartite_Graph &amp;M, int a, int b):&#160;bfs.cpp']]]
];

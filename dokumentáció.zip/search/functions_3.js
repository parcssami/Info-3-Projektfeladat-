var searchData=
[
  ['geta_0',['GetA',['../class_bipartite___graph.html#ae51e5263b0cec0bf40213834b02fe609',1,'Bipartite_Graph']]],
  ['getb_1',['GetB',['../class_bipartite___graph.html#a17cdbd0cf936ba16ea40a698995eeb13',1,'Bipartite_Graph']]]
];
